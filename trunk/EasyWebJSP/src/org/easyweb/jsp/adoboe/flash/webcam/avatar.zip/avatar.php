<?php
  /**
   * http://www.dongge.org/as_flase_avatar.html
   */
  if ($_GET['op'] != 'upload') {
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>php + flash 摄像头截取头像并上传</title>
  <link type="text/css" rel="stylesheet" media="all" href="http://www.dongge.org/misc/ui/themes/base/jquery.ui.css" />
  <script type="text/javascript" src="http://www.dongge.org/misc/jquery.js"></script>
  <script type="text/javascript" src="http://www.dongge.org/misc/ui/jquery.ui.js"></script>
  <style>
    body{text-align:center}
    #slider {margin: 15px 0;}
    #slider .ui-slider-range { background: #ef2929; }
    #slider .ui-slider-handle { border-color: #ef2929; }
  </style>
  <script>
  var swf = {}, dida = {};
  
  dida.readyCall = function() {
    $('#ok').attr({'disabled': false, 'value': '保存画面'});
    $('#open').attr({'value': '已打开'});
    
    $("#slider").slider({
      value: 260,
      min: 10,
      max: 260,
      step: 1,
      slide: function(event, ui) {
        swf.resizable(ui.value, ui.value);
      }
    });
  }
  
  dida.error = function(code) {
    var text = '';
    if (code == -1) {
      text = '您没有摄像头';
    } else if (code == -2) {
    	$('#ok').attr('disabled', true);
    	text = '您必须允许 flash 访问您的摄像头';
    }
    $('#error').text(text);
  }
  
  dida.completeCall = function(obj) {
    if (obj.filepath) {
      $('#preview').html('<img src="'+obj.filepath+'" />');
    } else if (obj.error) {
    	$('#preview').html('图片保存失败');
    }
    
    $('#ok').attr({'disabled': false, 'value': '保存画面'});
    $('#open').attr({'disabled': false, 'value': '重新打开摄像头'});
  }
  /**
   * 配置函数，flase读取此函数返回的数据做为配置。
   * 默认名称为 flash_data，可以 flase vars 标签里自行设置，如：funcName=my_data
   */
  function flash_data(){
    var opt = {
      cameraWidth: 260, // 摄像头视频宽度
      cameraHeight: 260, // 摄像头视频高度
      URLRequest: 'avatar.php?op=upload', // 上传路径
      errorCall: 'dida.error',  // 错误回调函数
      readyCall: 'dida.readyCall', // 摄像头已打开，准备就绪，可以开始拍摄，回调此函数
      completeCall: 'dida.completeCall' // 截屏图片已成功发送，回调此函数
    }
    return opt;
  }
  
  $(function() {
    
    if ($.browser.msie) {
      swf = window.myContent;
    } else {
      swf = window.document.myContent;
    }
    
    $('#ok').click(function() {
      swf.buttonShutter();
      $(this).attr({'disabled': true, 'value': '拍摄中，请稍候…'});
    });
    
    $('#open').click(function() {
      $(this).attr({'disabled': true, 'value': '正在打开，请稍候…'});
      swf.openCamera();
    });
  });
  </script>
  
</head>
<body>
  <h2>提示：图片会保存，<a href="http://www.dongge.org/as_flase_avatar.html">下载源代码并查看详细介绍</a></h2>
  <table>
  <tr><td colspan="2"><div id="error"></div></td></tr>
  <tr>
  <td valign="top">
  <object id="myContent" width=260 height=260 classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">
    <param name="movie" value="avatar.swf" />
    <param name="flashvars" value="" />
    <embed flashvars="" name="myContent" id="myContent" width="260" height="260" pluginspage="http://www.macromedia.com/go/getflashplayer" scale="noScale" name="myContent" mediawrapchecked="true" src="avatar.swf" type="application/x-shockwave-flash" splayername="SWF" tplayername="SWF" />
  </object>
  <div id="slider"></div>
  <input type="button" value="打开摄像头" id="open" />
  <input type="button" value="保存画面" id="ok" disabled="true" />
  </td>
  <td valign="top">
  <div id="preview"></div>
  </td>
  </tr>
  </table>
</body>
</html>
<?php
  }
  /**
   * 保存数据
   * flash 也许不与浏览器共享 session，可根据 url 参数验证用户
   */
  if ($data = file_get_contents("php://input", "r")) {
    $filepath = $_SERVER['REQUEST_TIME'].'.jpg';
    // 该地址必须返回 json，flash 将回调 completeCall，此数据做为参数传递
    if (file_put_contents($filepath, $data)) {
      $array = array('filepath' => $filepath);
      echo json_encode($array);
      exit;
    } else {
      echo '{"error": "失败"}';
    }
  }