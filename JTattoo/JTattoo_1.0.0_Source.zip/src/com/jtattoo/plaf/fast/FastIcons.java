/*
 * Copyright 2005 MH-Software-Entwicklung. All rights reserved.
 * Use is subject to license terms.
 */
package com.jtattoo.plaf.fast;

import com.jtattoo.plaf.BaseIcons;

/**
 * @author Michael Hagen
 */
public class FastIcons extends BaseIcons {
}
